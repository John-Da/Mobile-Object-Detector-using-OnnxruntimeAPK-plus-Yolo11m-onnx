package com.detection.detectto

data class ModelFile(
    val name: String,
    val path: String,
)
